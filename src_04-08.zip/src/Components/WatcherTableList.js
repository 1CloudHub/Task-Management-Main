import React from "react";

function WatcherTableList() {
  return <div>WatcherTableList</div>;
}

export default WatcherTableList;
