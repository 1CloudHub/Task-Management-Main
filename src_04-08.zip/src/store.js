import { createStoreHook } from "react-redux";
const store = createStoreHook({}, {});

export default store;
