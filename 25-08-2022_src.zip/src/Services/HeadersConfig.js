import { InMemoryCache } from "@apollo/client/cache";
import { ApolloClient } from "@apollo/client/core";

const userId = localStorage.getItem("userId");
const authToken = localStorage.getItem("jwt-token");
const url = process.env.REACT_APP_GRAPHQL_SERVICE_URL;
console.log("url : ", url);
console.log("userId : ", userId);
console.log("authToken : ", authToken);

export const Config = {
  "Accept-Encoding": "gzip,deflate,br",
  Connection: "keep-alive",
  // userId: "18",
  userId: userId,
  "Authentication-Token":
    "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIyNSIsImlhdCI6MTY2MTQxODkwOSwiZXhwIjoxNjc5NDE4OTA5fQ.9kXP1OWEhB8aqzKseoJs_mhZ0ujhgQq6-T03yMJIQ_0",
  // "Authentication-Token":
  //   "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxOCIsImlhdCI6MTY1OTA5NDkxMiwiZXhwIjoxNjc3MDk0OTEyfQ.WwSyLTd1FQYJs5u4jEFl0U6ayn6g5Wlx-mOgNfthAog",
  "Access-Control-Allow-Origin": "*",
};

export const Client = new ApolloClient({
  uri: url,
  cache: new InMemoryCache(),
  fetchOptions: {
    mode: "no-cors",
  },
  headers: Config,
});
