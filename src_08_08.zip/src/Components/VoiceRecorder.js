import React from "react";

function VoiceRecorder() {
  return <div>VoiceRecorder</div>;
}

export default VoiceRecorder;
