import React from "react";
import { Tab, Tabs } from "react-bootstrap";
import Footer from "./Footer";
import Graphs from "./Graphs/Graphs";
import AppNavBar from "./MIUI/AppNavBar";
import SideNavDrawer from "./MIUI/SideNavDrawer";
import NavBar from "./Nav-bar";
import TableList from "./TableList";
import { useQuery, gql } from "@apollo/client";
import CreatorTableList from "./Graphs/CreatorTableList";
import WatcherTableList from "./WatcherTableList";
import { getUser } from "react-oidc-client";
import { FaPlus } from "react-icons/fa";
import { Link } from "react-router-dom";
import CardList from "./CardList";

const FILTERED_TASK_QUERY = gql`
  query GETALL($request: SearchRequest) {
    getFilteredTasks(request: $request) {
      title
      description
      status
      taskId
      categoryId
      createdBy
      currentAssignee
      dueDate {
        formatString(format: "MM-dd-yyyy")
      }
    }
  }
`;

function Dashboard({ logoutClick, userDetails }) {
  const forHandlerResponse = useQuery(FILTERED_TASK_QUERY, {
    variables: {
      request: {
        page: 0,
        size: 10,
      },
      filters: [
        {
          filterKey: "currentAssignee",
          operator: "EQUAL",
          values: ["0"],
        },
      ],
      sorts: [
        {
          key: "taskId",
          direction: "DESC",
        },
      ],
    },
  });
  const forCreatorResponse = useQuery(FILTERED_TASK_QUERY, {
    variables: {
      request: {
        page: 0,
        size: 10,
      },
      filters: [
        {
          filterKey: "createdBy",
          operator: "EQUAL",
          values: ["1"],
        },
      ],
      sorts: [
        {
          key: "taskId",
          direction: "DESC",
        },
      ],
    },
  });
  const forWatcherResponse = useQuery(FILTERED_TASK_QUERY, {
    variables: {
      request: {
        page: 0,
        size: 10,
      },
      filters: [
        {
          filterKey: "createdBy",
          operator: "EQUAL",
          values: ["1"],
        },
      ],
      sorts: [
        {
          key: "taskId",
          direction: "DESC",
        },
      ],
    },
  });

  return (
    <div>
      <NavBar logoutClick={logoutClick} userDetails={userDetails} />
      {/* <AppNavBar />
      <SideNavDrawer /> */}
      <br />
      <br />

      <div className="main-container">
        <div className="container-fluid">
          <div className="marginLeft5">
            <h5 className="themeColor"> Dashboard </h5>
          </div>
          <Tabs
            defaultActiveKey="handle"
            id="dashboard-nav-tab-id"
            className="mb-3 text-danger dashboard-tabs"
          >
            <Tab className="dashboard-tab" eventKey="handle" title="Handler">
              {forHandlerResponse.data && (
                <>
                  <CardList />
                  <TableList response={forHandlerResponse} />
                  <Graphs response={forHandlerResponse} />
                </>
              )}
            </Tab>
            <Tab eventKey="watch" title="Watcher">
              <TableList columns={""} />
              <Graphs />

              <WatcherTableList />
            </Tab>
            <Tab eventKey="create" title="Creator">
              <CreatorTableList />
              <Graphs />
            </Tab>
          </Tabs>
        </div>
      </div>
      <Link to="/AddTask" className="float">
        <FaPlus className="mt-3" />
      </Link>
      <Footer />
    </div>
  );
}

export default Dashboard;
