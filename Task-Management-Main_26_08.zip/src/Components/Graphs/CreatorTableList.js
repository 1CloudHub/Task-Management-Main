import React from "react";

function CreatorTableList() {
  return <div>CreatorTableList</div>;
}

export default CreatorTableList;
