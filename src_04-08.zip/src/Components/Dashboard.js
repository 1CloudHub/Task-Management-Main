import {
  ApolloClient,
  gql,
  InMemoryCache,
  useQuery,
  useLazyQuery,
} from "@apollo/client";
import axios from "axios";
import { React, useEffect, useState } from "react";
import { Card, Modal, Tab, Tabs } from "react-bootstrap";
import Accordion from "react-bootstrap/Accordion";
import ReactDatePicker from "react-datepicker";
import { BsCalendar } from "react-icons/bs";
import {
  FaCircle,
  FaFilter,
  FaPlus,
  FaSortAmountDown,
  FaTimes,
} from "react-icons/fa";
import { Link } from "react-router-dom";
import Footer from "./Footer";
import Graphs from "./Graphs/Graphs";
import NavBar from "./Nav-bar";

const FILTERED_TASK_QUERY = gql`
  query GETALL($request: SearchRequest) {
    getFilteredTasks(request: $request) {
      title
      description
      status
      taskId
      categoryId
      createdBy
      currentAssignee
      dueDate {
        formatString(format: "MM-dd-yyyy")
      }
    }
  }
`;

const CATEGORY_QUERY = gql`
  {
    getCategories {
      categoryId
      name
      createdBy
    }
  }
`;

const CATEGORY_QUERY_1 = `
  {
    getCategories {
      categoryId
      name
      createdBy
    }
  }
`;

const SORT_QUERY = gql`
  query ($request: SearchRequest) {
    getFilteredTasks(request: $request) {
      title

      createdBy
      currentAssignee
      description
      status
      taskId
      dueDate {
        formatString(format: "MM-dd-yyyy")
      }
    }
  }
`;

function Dashboard({ logoutClick, userDetails }) {
  const [startDate, setStartDate] = useState();
  const [endDate, setEndDate] = useState(new Date());
  const forHandlerResponse = useQuery(FILTERED_TASK_QUERY, {
    variables: {
      request: {
        page: 0,
        size: 10,
        filters: [
          {
            filterKey: "categoryId",
            operator: "EQUAL",
            values: ["1"],
          },
        ],
        sorts: [
          {
            key: "taskId",
            direction: "DESC",
          },
        ],
      },
    },
  });
  const handlerResponse = {
    data: {
      getFilteredTasks: [
        {
          title: "subject",
          createdBy: 1,
          currentAssignee: 1,
          description: "description",
          status: 0,
          taskId: "76",
          dueDate: null,
        },
        {
          title: "subject",
          createdBy: 1,
          currentAssignee: 1,
          description: "description",
          status: 0,
          taskId: "75",
          dueDate: null,
        },
        {
          title: "subject",
          createdBy: 1,
          currentAssignee: 1,
          description: "description",
          status: 0,
          taskId: "74",
          dueDate: null,
        },
        {
          title: "subject",
          createdBy: 1,
          currentAssignee: 1,
          description: "description",
          status: 0,
          taskId: "73",
          dueDate: null,
        },
        {
          title: "subject",
          createdBy: 1,
          currentAssignee: 1,
          description: "description",
          status: 0,
          taskId: "72",
          dueDate: null,
        },
      ],
    },
  };
  const forCreatorResponse = useQuery(FILTERED_TASK_QUERY, {
    variables: {
      request: {
        page: 0,
        size: 10,
      },
      filters: [
        {
          filterKey: "createdBy",
          operator: "EQUAL",
          values: ["1"],
        },
      ],
      sorts: [
        {
          key: "taskId",
          direction: "DESC",
        },
      ],
    },
  });
  const forWatcherResponse = useQuery(FILTERED_TASK_QUERY, {
    variables: {
      request: {
        page: 0,
        size: 10,
      },
      filters: [
        {
          filterKey: "categoryId",
          operator: "EQUAL",
          values: ["1"],
        },
      ],
      sorts: [
        {
          key: "taskId",
          direction: "DESC",
        },
      ],
    },
  });
  const categoryResponse = useQuery(CATEGORY_QUERY);
  const handleCategoryChange = (selectedValue) => {
    console.log(selectedValue.target.value);
  };
  const handleEyeIconClick = (file) => {
    setShowViewDocPopup(true);
  };
  const handleCloseClick = () => setShowViewDocPopup(false);
  const [showViewDocPopup, setShowViewDocPopup] = useState(false);
  const [handleSort, sortResponse] = useLazyQuery(SORT_QUERY, {
    variables: {
      request: {
        page: 0,
        size: 5,
        filters: [
          {
            filterKey: "createdBy",
            operator: "EQUAL",
            values: ["1"],
          },
        ],
        sorts: [
          {
            key: "taskId",
            direction: "ASC",
          },
        ],
      },
    },
  });

  let sortRes = {
    data: {
      getFilteredTasks: [
        {
          title: "Add Design Spec",
          createdBy: 1,
          currentAssignee: null,
          description: "descp1",
          status: 0,
          taskId: "1",
          dueDate: null,
        },
        {
          title: "Add Test Cases",
          createdBy: 1,
          currentAssignee: null,
          description: "",
          status: 2,
          taskId: "2",
          dueDate: null,
        },
        {
          title: "Remove Hardcode",
          createdBy: 1,
          currentAssignee: null,
          description: "descp3",
          status: 0,
          taskId: "3",
          dueDate: null,
        },
        {
          title: "UploadDoc",
          createdBy: 1,
          currentAssignee: null,
          description: "descp4",
          status: 0,
          taskId: "4",
          dueDate: null,
        },
        {
          title: "Db migrationsetup",
          createdBy: 1,
          currentAssignee: null,
          description: "descp5",
          status: 1,
          taskId: "5",
          dueDate: null,
        },
      ],
    },
  };

  // console.log("sortResponse : ", sortResponse);
  const onSubmitFilter = () => {};

  // const
  const client = new ApolloClient({
    uri: "http://3.110.3.72/graphql",
    cache: new InMemoryCache(),
    fetchOptions: {
      mode: "no-cors",
    },
    headers: {
      "Authentication-Token": "saldfal00965-klal998-jknj",
      userId: "1",
    },
  });
  const [response, setResponse] = useState();

  useEffect(() => {
    client
      .query({
        query: FILTERED_TASK_QUERY,
        variables: {
          request: {
            page: 0,
            size: 10,
            filters: [
              {
                filterKey: "categoryId",
                operator: "EQUAL",
                values: ["1"],
              },
            ],
            sorts: [
              {
                key: "status",
                direction: "DESC",
              },
            ],
          },
        },
      })
      .then((response) => {
        console.log("response ::::::::", response);
        setResponse(response);
      })
      .catch((err) => console.error(err));
  }, []);

  const [defDescSort, setDefSort] = useState(true);

  const handleSorter = () => {
    console.log("click");
    setDefSort(!defDescSort);

    if (defDescSort) {
      client
        .query({
          query: FILTERED_TASK_QUERY,
          variables: {
            request: {
              page: 0,
              size: 10,
              filters: [
                {
                  filterKey: "categoryId",
                  operator: "EQUAL",
                  values: ["1"],
                },
              ],
              sorts: [
                {
                  key: "status",
                  direction: "ASC",
                },
              ],
            },
          },
        })
        .then((response) => {
          console.log("response ::::::::", response);
          setResponse(response);
        })
        .catch((err) => console.error(err));
    } else {
      client
        .query({
          query: FILTERED_TASK_QUERY,
          variables: {
            request: {
              page: 0,
              size: 10,
              filters: [
                {
                  filterKey: "categoryId",
                  operator: "EQUAL",
                  values: ["1"],
                },
              ],
              sorts: [
                {
                  key: "status",
                  direction: "DESC",
                },
              ],
            },
          },
        })
        .then((response) => {
          console.log("response ::::::::", response);
          setResponse(response);
        })
        .catch((err) => console.error(err));
    }
  };

  return (
    <div>
      <NavBar logoutClick={logoutClick} userDetails={userDetails} />
      {/* <AppNavBar />
      <SideNavDrawer /> */}
      <br />
      <br />

      <div className="main-container">
        <div className="container-fluid">
          <Tabs
            defaultActiveKey="handle"
            id="dashboard-nav-tab-id"
            className="mb-2 text-danger dashboard-tabs"
          >
            <Tab className="dashboard-tab" eventKey="handle" title="Handler">
              {response && (
                <>
                  <div className="filters-sorting ">
                    <div className="text-end ">
                      <span
                        className="filter-icons cursor-pointer"
                        onClick={handleEyeIconClick}
                      >
                        <FaFilter />
                      </span>
                      <span
                        className="filter-icons cursor-pointer"
                        onClick={handleSorter}
                      >
                        <FaSortAmountDown />
                      </span>
                    </div>
                  </div>
                  <div className="show-web">
                    <div className="row ">
                      <div className="col-xs-12 col-sm-12 col-md-11 col-lg-11">
                        <Accordion>
                          <Accordion.Item eventKey="0">
                            <Accordion.Header>
                              <FaFilter />
                            </Accordion.Header>
                            <Accordion.Body>
                              <form onSubmit={onSubmitFilter}>
                                <div className="row">
                                  <div className=" col-xs-12 col-sm-12 col-md-3 col-lg-3">
                                    <label className=" w-100">
                                      {" "}
                                      <span className="filter-span-header">
                                        Start Date
                                      </span>
                                      <div className="d-flex form-control cursor-pointer ">
                                        <ReactDatePicker
                                          type="text"
                                          name="fromDate"
                                          className="datePickerField col-lg-12 border-0 "
                                          dateFormat="dd-MM-yyyy"
                                          selected={startDate}
                                          placeholderText="start date"
                                          onChange={(date) =>
                                            setStartDate(date)
                                          }
                                        />
                                        <BsCalendar className="mt-1" />
                                      </div>
                                    </label>
                                  </div>
                                  <div className=" col-xs-12 col-sm-12 col-md-3 col-lg-3">
                                    <label className="w-100">
                                      {" "}
                                      <span className="filter-span-header">
                                        End Date
                                      </span>
                                      <div className="d-flex form-control cursor-pointer ">
                                        <ReactDatePicker
                                          type="text"
                                          name="fromDate"
                                          className="datePickerField col-lg-12 border-0 "
                                          dateFormat="dd-MM-yyyy"
                                          minDate={startDate}
                                          selected={endDate}
                                          placeholderText="end date"
                                          onChange={(date) => setEndDate(date)}
                                        />
                                        <BsCalendar className="mt-1" />
                                      </div>
                                    </label>
                                  </div>
                                  <div className=" col-xs-12 col-sm-12 col-md-3 col-lg-3">
                                    <label>
                                      <span className="filter-span-header">
                                        Category
                                      </span>{" "}
                                    </label>
                                    <select
                                      onChange={handleCategoryChange}
                                      className=" form-control"
                                    >
                                      <option value="">All</option>
                                      {categoryResponse.data &&
                                        categoryResponse.data.getCategories.map(
                                          (item, index) => {
                                            return (
                                              <option
                                                key={index}
                                                value={item.categoryId}
                                              >
                                                {item.name}
                                              </option>
                                            );
                                          }
                                        )}
                                    </select>
                                  </div>
                                  <div className=" col-xs-12 col-sm-12 col-md-3 col-lg-3">
                                    <div className="text-center pt-3">
                                      <button
                                        type="submit"
                                        className="btn btn-clr rounded-0 filter-btn-submit"
                                      >
                                        submit
                                      </button>
                                    </div>
                                  </div>
                                </div>
                              </form>
                            </Accordion.Body>
                          </Accordion.Item>
                        </Accordion>
                      </div>
                      <div className="col-xs-12 col-sm-12 col-md-1 col-lg-1 ">
                        <div className="btn d-flex justify-content-center  card p-1">
                          <span onClick={handleSorter}>
                            <FaSortAmountDown />
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* <br /> */}
                    <div>
                      {response.data.getFilteredTasks.map((item, index) => {
                        return (
                          <>
                            <div key={index}>
                              {" "}
                              <div className="row ">
                                {index < 3 && (
                                  <>
                                    <div className="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                      <Card className="p-2 card-bg backgroundCard rounded-0 m-1 ">
                                        <div className="d-flex">
                                          {" "}
                                          <div className="w-75 ml-2">
                                            {" "}
                                            <div>
                                              {" "}
                                              <b> {item.title}</b>
                                            </div>
                                            <div>
                                              {" "}
                                              {item.createdBy} +{" "}
                                              {item.currentAssignee}{" "}
                                            </div>
                                            <div>
                                              {" "}
                                              <b> Due : </b>{" "}
                                              {item.dueDate &&
                                                item.dueDate.formatString}{" "}
                                            </div>{" "}
                                          </div>
                                          <div className="floatRight mt-4">
                                            <div>
                                              {" "}
                                              {item.status == "Due Past" ? (
                                                <FaCircle className="MyTaskStatusCircleDuePast" />
                                              ) : item.status ==
                                                "InProgress" ? (
                                                <FaCircle className="MyTaskStatusCircleInprogress" />
                                              ) : item.status == "New" ? (
                                                <FaCircle className="MyTaskStatusCircleNew" />
                                              ) : (
                                                ""
                                              )}{" "}
                                            </div>
                                          </div>{" "}
                                        </div>{" "}
                                      </Card>
                                    </div>
                                  </>
                                )}
                                {index > 4 && (
                                  <>
                                    <div className="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                      <Card className="p-2 card-bg backgroundCard rounded-0 m-1 ">
                                        <div className="d-flex">
                                          {" "}
                                          <div className="w-75 ml-2">
                                            {" "}
                                            <div>
                                              {" "}
                                              <b> {item.title}</b>
                                            </div>
                                            <div>
                                              {" "}
                                              {item.createdBy} +{" "}
                                              {item.currentAssignee}{" "}
                                            </div>
                                            <div>
                                              {" "}
                                              <b> Due : </b>{" "}
                                              {item.dueDate &&
                                                item.dueDate.formatString}{" "}
                                            </div>{" "}
                                          </div>
                                          <div className="floatRight mt-4">
                                            <div>
                                              {" "}
                                              {item.status == "Due Past" ? (
                                                <FaCircle className="MyTaskStatusCircleDuePast" />
                                              ) : item.status ==
                                                "InProgress" ? (
                                                <FaCircle className="MyTaskStatusCircleInprogress" />
                                              ) : item.status == "New" ? (
                                                <FaCircle className="MyTaskStatusCircleNew" />
                                              ) : (
                                                ""
                                              )}{" "}
                                            </div>
                                          </div>{" "}
                                        </div>{" "}
                                      </Card>
                                    </div>
                                  </>
                                )}
                              </div>
                            </div>{" "}
                          </>
                        );
                      })}
                    </div>
                  </div>
                  <div className="show-mobile-icons">
                    <div className="row ">
                      <div className="col-xs-12 col-sm-12 col-md-1 col-lg-1 ">
                        <div className="btn d-flex justify-content-center  card p-1">
                          <span onClick={handleSorter}>
                            <FaSortAmountDown />
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* <br /> */}
                    <div>
                      {response.data.getFilteredTasks.map((item, index) => {
                        return (
                          <>
                            <div key={index}>
                              <div className="row ">
                                <div className="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                  <Card className="p-2 card-bg backgroundCard rounded-0 m-1 ">
                                    <div className="d-flex">
                                      {" "}
                                      <div className="w-75 ml-2">
                                        {" "}
                                        <div>
                                          {" "}
                                          <b> {item.title}</b>
                                        </div>
                                        <div>
                                          {" "}
                                          {item.createdBy} +{" "}
                                          {item.currentAssignee}{" "}
                                        </div>
                                        <div>
                                          {" "}
                                          <b> Due : </b>{" "}
                                          {item.dueDate &&
                                            item.dueDate.formatString}{" "}
                                        </div>{" "}
                                      </div>
                                      <div className="floatRight mt-4">
                                        <div>
                                          {" "}
                                          {item.status == "Due Past" ? (
                                            <FaCircle className="MyTaskStatusCircleDuePast" />
                                          ) : item.status == "InProgress" ? (
                                            <FaCircle className="MyTaskStatusCircleInprogress" />
                                          ) : item.status == "New" ? (
                                            <FaCircle className="MyTaskStatusCircleNew" />
                                          ) : (
                                            ""
                                          )}{" "}
                                        </div>
                                      </div>{" "}
                                    </div>{" "}
                                  </Card>
                                </div>
                              </div>
                            </div>{" "}
                          </>
                        );
                      })}
                    </div>
                  </div>

                  {/* <CardList /> */}
                  {/* <TableList response={forHandlerResponse} /> */}
                  <Graphs response={handlerResponse} />
                </>
              )}
            </Tab>
            <Tab eventKey="watch" title="Watcher">
              {handlerResponse.data && (
                <>
                  <div className="row d-flex">
                    <div className="filters-sorting">
                      {/* <div className="d-flex">
                        <span className="ml-1">
                          <FaFilter />
                        </span>
                        <FaSortAmountDown />
                      </div> */}
                    </div>
                    <div className="col-xs-12 col-sm-12 col-md-11 col-lg-11">
                      <Accordion>
                        <Accordion.Item eventKey="0">
                          <Accordion.Header>
                            <FaFilter />
                          </Accordion.Header>
                          <Accordion.Body>
                            <div className="row">
                              <div className=" col-xs-12 col-sm-12 col-md-3 col-lg-3">
                                <label className=" w-100">
                                  {" "}
                                  <span className="filter-span-header">
                                    Start Date
                                  </span>
                                  <div className="d-flex form-control cursor-pointer ">
                                    <ReactDatePicker
                                      type="text"
                                      name="fromDate"
                                      className="datePickerField col-lg-12 border-0 "
                                      dateFormat="dd-MM-yyyy"
                                      selected={startDate}
                                      placeholderText="start date"
                                      onChange={(date) => setStartDate(date)}
                                    />
                                    <BsCalendar className="mt-1" />
                                  </div>
                                </label>
                              </div>
                              <div className=" col-xs-12 col-sm-12 col-md-3 col-lg-3">
                                <label className="w-100">
                                  {" "}
                                  <span className="filter-span-header">
                                    End Date
                                  </span>
                                  <div className="d-flex form-control cursor-pointer ">
                                    <ReactDatePicker
                                      type="text"
                                      name="fromDate"
                                      className="datePickerField col-lg-12 border-0 "
                                      dateFormat="dd-MM-yyyy"
                                      minDate={startDate}
                                      selected={endDate}
                                      placeholderText="end date"
                                      onChange={(date) => setEndDate(date)}
                                    />
                                    <BsCalendar className="mt-1" />
                                  </div>
                                </label>
                              </div>
                              <div className=" col-xs-12 col-sm-12 col-md-3 col-lg-3">
                                <label>
                                  <span className="filter-span-header">
                                    Category
                                  </span>{" "}
                                </label>
                                <select
                                  onChange={handleCategoryChange}
                                  className=" form-control"
                                >
                                  <option value="">All</option>
                                  {categoryResponse.data &&
                                    categoryResponse.data.getCategories.map(
                                      (item, index) => {
                                        return (
                                          <option
                                            key={index}
                                            value={item.categoryId}
                                          >
                                            {item.name}
                                          </option>
                                        );
                                      }
                                    )}
                                </select>
                              </div>
                              <div className=" col-xs-12 col-sm-12 col-md-3 col-lg-3">
                                <div className="text-center pt-3">
                                  <button
                                    type="submit"
                                    className="btn btn-clr rounded-0 filter-btn-submit"
                                  >
                                    submit
                                  </button>
                                </div>
                              </div>
                            </div>
                          </Accordion.Body>
                        </Accordion.Item>
                      </Accordion>
                    </div>
                    <div className="col-xs-12 col-sm-12 col-md-1 col-lg-1">
                      <span className="btn d-flex justify-content-center card p-2">
                        <FaSortAmountDown />
                      </span>
                    </div>
                  </div>
                  <br />
                  <div>
                    {handlerResponse.data.getFilteredTasks.map(
                      (item, index) => {
                        return (
                          <>
                            <div key={index}>
                              {" "}
                              <div className="row">
                                {/* <div className=" "> */}
                                {/* {index < 5 ? ( */}
                                <div className="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                  <Card className="p-2 card-bg backgroundCard rounded-0 m-1 ">
                                    <div className="d-flex">
                                      {" "}
                                      <div className="w-75 ml-2">
                                        {" "}
                                        <div>
                                          {" "}
                                          <b> {item.title}</b>
                                        </div>
                                        <div>
                                          {" "}
                                          {item.createdBy} +{" "}
                                          {item.currentAssignee}{" "}
                                        </div>
                                        <div>
                                          {" "}
                                          <b> Due : </b>{" "}
                                          {item.dueDate &&
                                            item.dueDate.formatString}{" "}
                                        </div>{" "}
                                      </div>
                                      <div className="floatRight mt-4">
                                        <div>
                                          {" "}
                                          {item.status == "Due Past" ? (
                                            <FaCircle className="MyTaskStatusCircleDuePast" />
                                          ) : item.status == "InProgress" ? (
                                            <FaCircle className="MyTaskStatusCircleInprogress" />
                                          ) : item.status == "New" ? (
                                            <FaCircle className="MyTaskStatusCircleNew" />
                                          ) : (
                                            ""
                                          )}{" "}
                                        </div>
                                      </div>{" "}
                                    </div>{" "}
                                  </Card>
                                </div>
                                {/* ) : ( */}
                                <div className="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                  <Card className="p-2 card-bg backgroundCard rounded-0 m-1 ">
                                    <div className="d-flex">
                                      {" "}
                                      <div className="w-75 ml-2">
                                        {" "}
                                        <div>
                                          {" "}
                                          <b> {item.title}</b>
                                        </div>
                                        <div>
                                          {" "}
                                          {item.createdBy} +{" "}
                                          {item.currentAssignee}{" "}
                                        </div>
                                        <div>
                                          {" "}
                                          <b> Due : </b>{" "}
                                          {item.dueDate &&
                                            item.dueDate.formatString}{" "}
                                        </div>{" "}
                                      </div>
                                      <div className="floatRight mt-4">
                                        <div>
                                          {" "}
                                          {item.taskStatus == "Due Past" ? (
                                            <FaCircle className="MyTaskStatusCircleDuePast" />
                                          ) : item.taskStatus ==
                                            "InProgress" ? (
                                            <FaCircle className="MyTaskStatusCircleInprogress" />
                                          ) : item.taskStatus == "New" ? (
                                            <FaCircle className="MyTaskStatusCircleNew" />
                                          ) : (
                                            ""
                                          )}{" "}
                                        </div>
                                      </div>{" "}
                                    </div>{" "}
                                  </Card>
                                </div>
                                {/* )}{" "} */}
                                {/* </div> */}
                                {/* <div className="col-xs-12 col-sm-12 col-md-6 col-lg-6 ">
                                <Card className="p-2 card-bg backgroundCard rounded-0 m-1 ">
                                  <div className="d-flex">
                                    {" "}
                                    <div className="w-75 ml-2">
                                      {" "}
                                      <div>
                                        {" "}
                                        <b> {item.subject}</b>
                                      </div>
                                      <div>
                                        {" "}
                                        {item.createdBy} + {item.assignedTo}{" "}
                                      </div>
                                      <div>
                                        {" "}
                                        <b> Due : </b> {item.createdOn}{" "}
                                      </div>{" "}
                                    </div>
                                    <div className="floatRight mt-4">
                                      <div>
                                        {" "}
                                        {item.taskStatus == "Due Past" ? (
                                          <FaCircle className="MyTaskStatusCircleDuePast" />
                                        ) : item.taskStatus == "InProgress" ? (
                                          <FaCircle className="MyTaskStatusCircleInprogress" />
                                        ) : item.taskStatus == "New" ? (
                                          <FaCircle className="MyTaskStatusCircleNew" />
                                        ) : (
                                          ""
                                        )}{" "}
                                      </div>
                                    </div>{" "}
                                  </div>{" "}
                                </Card>{" "}
                              </div> */}
                              </div>
                            </div>{" "}
                          </>
                        );
                      }
                    )}
                  </div>
                  {/* <CardList /> */}
                  {/* <TableList response={forHandlerResponse} /> */}
                  <Graphs response={handlerResponse} />
                </>
              )}
            </Tab>
            <Tab eventKey="create" title="Creator">
              {handlerResponse.data && (
                <>
                  <div className="row d-flex">
                    <div className="filters-sorting">
                      {/* <div className="d-flex">
                        <span className="ml-1">
                          <FaFilter />
                        </span>
                        <FaSortAmountDown />
                      </div> */}
                    </div>
                    <div className="col-xs-12 col-sm-12 col-md-11 col-lg-11">
                      <Accordion>
                        <Accordion.Item eventKey="0">
                          <Accordion.Header>
                            <FaFilter />
                          </Accordion.Header>
                          <Accordion.Body>
                            <div className="row">
                              <div className=" col-xs-12 col-sm-12 col-md-3 col-lg-3">
                                <label className=" w-100">
                                  {" "}
                                  <span className="filter-span-header">
                                    Start Date
                                  </span>
                                  <div className="d-flex form-control cursor-pointer ">
                                    <ReactDatePicker
                                      type="text"
                                      name="fromDate"
                                      className="datePickerField col-lg-12 border-0 "
                                      dateFormat="dd-MM-yyyy"
                                      selected={startDate}
                                      placeholderText="start date"
                                      onChange={(date) => setStartDate(date)}
                                    />
                                    <BsCalendar className="mt-1" />
                                  </div>
                                </label>
                              </div>
                              <div className=" col-xs-12 col-sm-12 col-md-3 col-lg-3">
                                <label className="w-100">
                                  {" "}
                                  <span className="filter-span-header">
                                    End Date
                                  </span>
                                  <div className="d-flex form-control cursor-pointer ">
                                    <ReactDatePicker
                                      type="text"
                                      name="fromDate"
                                      className="datePickerField col-lg-12 border-0 "
                                      dateFormat="dd-MM-yyyy"
                                      minDate={startDate}
                                      selected={endDate}
                                      placeholderText="end date"
                                      onChange={(date) => setEndDate(date)}
                                    />
                                    <BsCalendar className="mt-1" />
                                  </div>
                                </label>
                              </div>
                              <div className=" col-xs-12 col-sm-12 col-md-3 col-lg-3">
                                <label>
                                  <span className="filter-span-header">
                                    Category
                                  </span>{" "}
                                </label>
                                <select
                                  onChange={handleCategoryChange}
                                  className=" form-control"
                                >
                                  <option value="">All</option>
                                  {categoryResponse.data &&
                                    categoryResponse.data.getCategories.map(
                                      (item, index) => {
                                        return (
                                          <option
                                            key={index}
                                            value={item.categoryId}
                                          >
                                            {item.name}
                                          </option>
                                        );
                                      }
                                    )}
                                </select>
                              </div>
                              <div className=" col-xs-12 col-sm-12 col-md-3 col-lg-3">
                                <div className="text-center pt-3">
                                  <button
                                    type="submit"
                                    className="btn btn-clr rounded-0 filter-btn-submit"
                                  >
                                    submit
                                  </button>
                                </div>
                              </div>
                            </div>
                          </Accordion.Body>
                        </Accordion.Item>
                      </Accordion>
                    </div>
                    <div className="col-xs-12 col-sm-12 col-md-1 col-lg-1">
                      <span className="btn d-flex justify-content-center card p-2">
                        <FaSortAmountDown />
                      </span>
                    </div>
                  </div>
                  <br />
                  <div>
                    {handlerResponse.data.getFilteredTasks.map(
                      (item, index) => {
                        return (
                          <>
                            <div key={index}>
                              {" "}
                              <div className="row">
                                {/* <div className=" "> */}
                                {/* {index < 5 ? ( */}
                                <div className="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                  <Card className="p-2 card-bg backgroundCard rounded-0 m-1 ">
                                    <div className="d-flex">
                                      {" "}
                                      <div className="w-75 ml-2">
                                        {" "}
                                        <div>
                                          {" "}
                                          <b> {item.title}</b>
                                        </div>
                                        <div>
                                          {" "}
                                          {item.createdBy} +{" "}
                                          {item.currentAssignee}{" "}
                                        </div>
                                        <div>
                                          {" "}
                                          <b> Due : </b>{" "}
                                          {item.dueDate &&
                                            item.dueDate.formatString}{" "}
                                        </div>{" "}
                                      </div>
                                      <div className="floatRight mt-4">
                                        <div>
                                          {" "}
                                          {item.status == "Due Past" ? (
                                            <FaCircle className="MyTaskStatusCircleDuePast" />
                                          ) : item.status == "InProgress" ? (
                                            <FaCircle className="MyTaskStatusCircleInprogress" />
                                          ) : item.status == "New" ? (
                                            <FaCircle className="MyTaskStatusCircleNew" />
                                          ) : (
                                            ""
                                          )}{" "}
                                        </div>
                                      </div>{" "}
                                    </div>{" "}
                                  </Card>
                                </div>
                                {/* ) : ( */}
                                <div className="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                  <Card className="p-2 card-bg backgroundCard rounded-0 m-1 ">
                                    <div className="d-flex">
                                      {" "}
                                      <div className="w-75 ml-2">
                                        {" "}
                                        <div>
                                          {" "}
                                          <b> {item.title}</b>
                                        </div>
                                        <div>
                                          {" "}
                                          {item.createdBy} +{" "}
                                          {item.currentAssignee}{" "}
                                        </div>
                                        <div>
                                          {" "}
                                          <b> Due : </b>{" "}
                                          {item.dueDate &&
                                            item.dueDate.formatString}{" "}
                                        </div>{" "}
                                      </div>
                                      <div className="floatRight mt-4">
                                        <div>
                                          {" "}
                                          {item.taskStatus == "Due Past" ? (
                                            <FaCircle className="MyTaskStatusCircleDuePast" />
                                          ) : item.taskStatus ==
                                            "InProgress" ? (
                                            <FaCircle className="MyTaskStatusCircleInprogress" />
                                          ) : item.taskStatus == "New" ? (
                                            <FaCircle className="MyTaskStatusCircleNew" />
                                          ) : (
                                            ""
                                          )}{" "}
                                        </div>
                                      </div>{" "}
                                    </div>{" "}
                                  </Card>
                                </div>
                                {/* )}{" "} */}
                                {/* </div> */}
                                {/* <div className="col-xs-12 col-sm-12 col-md-6 col-lg-6 ">
                                <Card className="p-2 card-bg backgroundCard rounded-0 m-1 ">
                                  <div className="d-flex">
                                    {" "}
                                    <div className="w-75 ml-2">
                                      {" "}
                                      <div>
                                        {" "}
                                        <b> {item.subject}</b>
                                      </div>
                                      <div>
                                        {" "}
                                        {item.createdBy} + {item.assignedTo}{" "}
                                      </div>
                                      <div>
                                        {" "}
                                        <b> Due : </b> {item.createdOn}{" "}
                                      </div>{" "}
                                    </div>
                                    <div className="floatRight mt-4">
                                      <div>
                                        {" "}
                                        {item.taskStatus == "Due Past" ? (
                                          <FaCircle className="MyTaskStatusCircleDuePast" />
                                        ) : item.taskStatus == "InProgress" ? (
                                          <FaCircle className="MyTaskStatusCircleInprogress" />
                                        ) : item.taskStatus == "New" ? (
                                          <FaCircle className="MyTaskStatusCircleNew" />
                                        ) : (
                                          ""
                                        )}{" "}
                                      </div>
                                    </div>{" "}
                                  </div>{" "}
                                </Card>{" "}
                              </div> */}
                              </div>
                            </div>{" "}
                          </>
                        );
                      }
                    )}
                  </div>
                  {/* <CardList /> */}
                  {/* <TableList response={forHandlerResponse} /> */}
                  <Graphs response={handlerResponse} />
                </>
              )}
            </Tab>
          </Tabs>
        </div>
      </div>
      <Link to="/AddTask" className="float">
        <FaPlus className="mt-3" />
      </Link>
      <Modal show={showViewDocPopup}>
        <Modal.Header>
          <div>Filter</div>
          <FaTimes onClick={handleCloseClick} />{" "}
        </Modal.Header>
        <Modal.Body>
          <div className="row">
            <div className=" col-xs-12 col-sm-12 col-md-3 col-lg-3">
              <label className=" w-100">
                {" "}
                <span className="filter-span-header">Start Date</span>
                <div className="d-flex form-control cursor-pointer ">
                  <ReactDatePicker
                    type="text"
                    name="fromDate"
                    className="datePickerField col-lg-12 border-0 "
                    dateFormat="dd-MM-yyyy"
                    selected={startDate}
                    placeholderText="start date"
                    onChange={(date) => setStartDate(date)}
                  />
                  <BsCalendar className="mt-1" />
                </div>
              </label>
            </div>
            <div className=" col-xs-12 col-sm-12 col-md-3 col-lg-3">
              <label className="w-100">
                {" "}
                <span className="filter-span-header">End Date</span>
                <div className="d-flex form-control cursor-pointer ">
                  <ReactDatePicker
                    type="text"
                    name="fromDate"
                    className="datePickerField col-lg-12 border-0 "
                    dateFormat="dd-MM-yyyy"
                    minDate={startDate}
                    selected={endDate}
                    placeholderText="end date"
                    onChange={(date) => setEndDate(date)}
                  />
                  <BsCalendar className="mt-1" />
                </div>
              </label>
            </div>
            <div className=" col-xs-12 col-sm-12 col-md-3 col-lg-3">
              <label>
                <span className="filter-span-header">Category</span>{" "}
              </label>
              <select onChange={handleCategoryChange} className=" form-control">
                <option value="">All</option>
                {categoryResponse.data &&
                  categoryResponse.data.getCategories.map((item, index) => {
                    return (
                      <option key={index} value={item.categoryId}>
                        {item.name}
                      </option>
                    );
                  })}
              </select>
            </div>
            <div className=" col-xs-12 col-sm-12 col-md-3 col-lg-3">
              <div className="text-center pt-3">
                <button
                  type="submit"
                  className="btn btn-clr rounded-0 filter-btn-submit"
                >
                  submit
                </button>
              </div>
            </div>
          </div>
        </Modal.Body>
      </Modal>
      <Footer />
    </div>
  );
}

export default Dashboard;
